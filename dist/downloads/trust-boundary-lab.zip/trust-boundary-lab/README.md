# Trust Boundary Lab

[![Checks](https://github.com/dhrubasuz/trust-boundary-lab/actions/workflows/checks.yml/badge.svg)](https://github.com/dhrubasuz/trust-boundary-lab/actions/workflows/checks.yml)

![Trust Boundary Lab by Dhruba Poudel](article/cover.png)

**A small security model that makes authorization decisions visible.**

I built Trust Boundary Lab to demonstrate why completing a payment form is not permission to activate a campaign. The lab follows one fictional command from an unsafe client-side decision through server-owned billing checks, account authorization, request-bound idempotency and delivery-time revalidation. I also included focused examples of a safe DOM text sink and session-bound CSRF checks.

**Original work by Dhruba Poudel.** This is an independently designed teaching model, not Facebook source code, a reconstruction of a historical Facebook finding, or evidence of its root cause or severity. Every account, campaign and token is fictional. The lab does not contact a network, run ads, process payments or call an external service.

[Read the companion article](https://about.dhrub.com.np/articles/payment-workflow-security.html) · [Download the source bundle](https://about.dhrub.com.np/downloads/trust-boundary-lab.zip)

## Run it

Use **Node.js 22 or newer**. There are no dependencies and nothing to install.

```sh
node --test campaign-security.test.mjs
node demo.mjs
```

The verified suite contains **41 passing tests**. The repository workflow runs the tests and demonstration on Node.js 22 and 24.

```text
Flawed UI-completion decision: ACTIVE
Server decision with no trusted billing: BILLING_REQUIRED
Server decision with approved account credit: PENDING_DELIVERY
Repeated command returns same event: true
Revalidated simulated dispatch: DELIVERED
Final fictional campaign state: ACTIVE
```

The deliberately flawed decision trusts `paymentStepComplete` from a browser form. The corrected model checks identity from a trusted session boundary, account membership, campaign ownership, server-owned billing eligibility, allowed lifecycle, integer-cent budget limits and currency. A verified approved-credit account is eligible without a credit card; the policy is billing authorization, not a mandatory card field.

## What the code demonstrates

| Boundary | Modelled control | Regression evidence |
| --- | --- | --- |
| Browser to command | Client completion and billing flags have no authority | Missing billing and client-spoof tests |
| Actor to account | Session identity, membership and campaign ownership | Cross-account and forged-identity tests |
| Intent to money | Integer cents, per-campaign limit and account currency | Invalid amount and boundary tests |
| Command to queue | Lifecycle check, intent-bound receipt and one outbox event | Replay, conflict and mutation-isolation tests |
| Queue to delivery | Recheck current membership, billing and spending policy | Revocation and changed-policy tests |
| Untrusted label to DOM | `textContent` on a fixed ordinary label container | Harmless markup marker and guarded fake element |
| Browser request to session | Exact configured origin and session-bound token comparison | Missing origin, cross-origin and invalid-token tests |

## Explore the implementation

- [`campaign-security.mjs`](campaign-security.mjs) contains the deliberately flawed decision and corrected model.
- [`campaign-security.test.mjs`](campaign-security.test.mjs) contains the regression suite.
- [`demo.mjs`](demo.mjs) runs the before-and-after walkthrough.
- [`verification.json`](verification.json) records a portable local verification receipt and source hashes.
- [`article/payment-workflow-security.html`](article/payment-workflow-security.html) is the self-contained article, with a matching [PDF reading copy](article/payment-workflow-security.pdf).

## Engineering boundaries

The store is synchronous and in memory. One Node.js event loop executes a mutation without yielding. The 25 promise-scheduled callers exercise replay in that model; they do **not** prove correctness across multiple processes, database workers, crashes or distributed services.

I modelled campaign changes, the receipt and an outbox event as one conceptual commit. A production service needs a real database transaction, unique receipt/event constraints, suitable row locking or optimistic concurrency, durable records and downstream idempotency. This lab does not claim exactly-once external effects. There is no authentication implementation, payment provider, signed webhook handler, rate limiter, durable job queue or audit service.

A replay returns the original accepted-command receipt after checking current account access and request intent. The receipt is not a delivery confirmation. A queued delivery independently checks current policy. An already delivered event returns its record; it does not undo an effect. Budget validation covers a per-campaign ceiling, not aggregate balance reservation, settlement, tax, exchange rates or fraud screening.

`renderLabel` is for a fixed ordinary text container such as a `div`, never a `script` or `style` element. Rich HTML needs appropriate contextual handling and a maintained sanitizer. Its test uses a fake element and a harmless marker, not a browser exploit. The CSRF helper is standalone, with no HTTP handler; real integration needs an authenticated session/request pipeline, cryptographically generated session-bound tokens and an explicit browser/non-browser origin policy. CSRF controls do not repair XSS. CSS is a styling language; XSS and CSRF are separate security classes.

## License and security

MIT © 2026 Dhruba Poudel. See [LICENSE](LICENSE) and [SECURITY.md](SECURITY.md). I have made no claim here about an original Facebook endpoint, CVE, bounty amount, severity score or historical implementation.
