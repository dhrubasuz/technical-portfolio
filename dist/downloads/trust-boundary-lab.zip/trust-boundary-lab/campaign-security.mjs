// Author: Dhruba Poudel. Original fictional teaching model, not Facebook code.
import { createHash, timingSafeEqual } from 'node:crypto';

export class PolicyError extends Error {
  constructor(code) { super(code); this.code = code; }
}
const deny = code => { throw new PolicyError(code); };
const copy = value => structuredClone(value);
const digest = value => createHash('sha256').update(JSON.stringify(value)).digest('hex');

// Deliberately flawed: a completed browser step is treated as billing authority.
export function vulnerableDecision(clientForm) {
  return clientForm.paymentStepComplete === true ? 'ACTIVE' : 'DRAFT';
}

export function billingEligible(account) {
  return account.billing?.status === 'VERIFIED' &&
    ['CARD', 'APPROVED_CREDIT'].includes(account.billing.kind);
}

export function requireCsrf({ origin, expectedOrigin, token, sessionToken }) {
  // expectedOrigin and sessionToken come from trusted server configuration/session.
  if (!expectedOrigin || origin !== expectedOrigin) deny('CSRF_ORIGIN');
  if (typeof token !== 'string' || typeof sessionToken !== 'string' ||
      token.length < 32 || token.length > 256 || sessionToken.length > 256) deny('CSRF_TOKEN');
  const supplied = Buffer.from(token, 'utf8');
  const expected = Buffer.from(sessionToken, 'utf8');
  if (supplied.length !== expected.length || !timingSafeEqual(supplied, expected)) deny('CSRF_TOKEN');
}

// Fixed ordinary label container (e.g. div), never a script/style element.
// DOM text context only. Rich HTML requires a maintained HTML sanitiser instead.
export function renderLabel(element, text) {
  element.textContent = String(text);
}

export class CampaignStore {
  #accounts; #campaigns; #receipts = new Map(); #outbox = new Map();
  constructor({ accounts, campaigns }) {
    this.#accounts = new Map(accounts.map(x => [x.id, copy(x)]));
    this.#campaigns = new Map(campaigns.map(x => [x.id, copy(x)]));
  }
  #authorize(actor, accountId, campaignId) {
    // actor is obtained from an authenticated server session, never a form field.
    const account = this.#accounts.get(accountId);
    const campaign = this.#campaigns.get(campaignId);
    if (!account || account.status !== 'ACTIVE' || !account.operators.includes(actor)) deny('FORBIDDEN');
    if (!campaign || campaign.accountId !== account.id) deny('FORBIDDEN');
    return { account, campaign };
  }
  #validateIntent(account, request) {
    if (!request || typeof request !== 'object') deny('INVALID_INTENT');
    const { budgetCents, currency, idempotencyKey } = request;
    if (!Number.isSafeInteger(budgetCents) || budgetCents < 1 ||
        budgetCents > account.maxCampaignCents) deny('INVALID_BUDGET');
    if (currency !== account.currency) deny('INVALID_CURRENCY');
    if (typeof idempotencyKey !== 'string' || !/^[A-Za-z0-9_-]{12,128}$/.test(idempotencyKey)) deny('INVALID_KEY');
    return { budgetCents, currency, idempotencyKey };
  }
  activate({ actor, accountId, campaignId, request }) {
    const { account, campaign } = this.#authorize(actor, accountId, campaignId);
    const intent = this.#validateIntent(account, request);
    const receiptKey = JSON.stringify([actor, accountId, intent.idempotencyKey]);
    const fingerprint = digest([actor, accountId, campaignId, intent.budgetCents, intent.currency]);
    const existing = this.#receipts.get(receiptKey);
    if (existing) {
      if (existing.fingerprint !== fingerprint) deny('IDEMPOTENCY_CONFLICT');
      return copy(existing.result);
    }
    if (campaign.status !== 'DRAFT') deny('INVALID_TRANSITION');
    if (!billingEligible(account)) deny('BILLING_REQUIRED');
    const updated = { ...campaign, status: 'PENDING_DELIVERY', budgetCents: intent.budgetCents, currency: intent.currency };
    const eventId = digest(['ACTIVATE', receiptKey, fingerprint]);
    const event = { id: eventId, type: 'CAMPAIGN_ACTIVATION', accountId, campaignId, actor, status: 'PENDING' };
    const result = { campaignId, status: updated.status, eventId };
    // No await or external calls: one synchronous in-memory commit. A real service
    // needs a DB transaction, UNIQUE receipt/event keys and concurrency control.
    this.#campaigns.set(campaignId, updated);
    this.#outbox.set(eventId, event);
    this.#receipts.set(receiptKey, { fingerprint, result: copy(result) });
    return copy(result);
  }
  deliver(eventId) {
    const event = this.#outbox.get(eventId);
    if (!event) deny('EVENT_NOT_FOUND');
    if (event.status === 'DELIVERED') return copy(event);
    // A queued job must recheck current authority, billing and lifecycle.
    const { account, campaign } = this.#authorize(event.actor, event.accountId, event.campaignId);
    if (!billingEligible(account)) deny('BILLING_REQUIRED');
    if (campaign.status !== 'PENDING_DELIVERY') deny('INVALID_TRANSITION');
    if (!Number.isSafeInteger(campaign.budgetCents) || campaign.budgetCents < 1 ||
        campaign.budgetCents > account.maxCampaignCents || campaign.currency !== account.currency) deny('INVALID_INTENT');
    const delivered = { ...event, status: 'DELIVERED' };
    // Simulates dispatch only; no ads, charges or external service calls occur.
    this.#campaigns.set(campaign.id, { ...campaign, status: 'ACTIVE' });
    this.#outbox.set(eventId, delivered);
    return copy(delivered);
  }
  // Trusted administrative changes simulate revocation between review and job.
  updateAccount(accountId, patch) {
    const account = this.#accounts.get(accountId);
    if (!account) deny('ACCOUNT_NOT_FOUND');
    this.#accounts.set(accountId, { ...account, ...copy(patch), id: account.id });
  }
  snapshot() {
    return copy({ accounts: [...this.#accounts.values()], campaigns: [...this.#campaigns.values()],
      receipts: [...this.#receipts.values()], outbox: [...this.#outbox.values()] });
  }
}
