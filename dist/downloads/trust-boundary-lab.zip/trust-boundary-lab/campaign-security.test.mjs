// Author: Dhruba Poudel. All accounts, tokens and scenarios are fictional.
import test from 'node:test';
import assert from 'node:assert/strict';
import { CampaignStore, vulnerableDecision, requireCsrf, renderLabel } from './campaign-security.mjs';

const token = 'fictional_session_token_1234567890abcdef';
const request = (patch = {}) => ({ budgetCents: 12000, currency: 'AUD', idempotencyKey: 'intent_0000000001', ...patch });
function makeStore({ billing = { kind: 'CARD', status: 'VERIFIED' }, status = 'DRAFT' } = {}) {
  return new CampaignStore({
    accounts: [
      { id: 'account-a', status: 'ACTIVE', operators: ['alice'], currency: 'AUD', maxCampaignCents: 50000, billing },
      { id: 'account-b', status: 'ACTIVE', operators: ['bob'], currency: 'AUD', maxCampaignCents: 50000, billing: { kind: 'CARD', status: 'VERIFIED' } },
    ],
    campaigns: [{ id: 'campaign-a', accountId: 'account-a', status }, { id: 'campaign-b', accountId: 'account-b', status: 'DRAFT' }],
  });
}
const activate = (store, patch = {}) => store.activate({ actor: 'alice', accountId: 'account-a', campaignId: 'campaign-a', request: request(), ...patch });
const code = expected => error => error.code === expected;

test('flawed decision accepts a client completion flag without billing evidence', () => {
  assert.equal(vulnerableDecision({ paymentStepComplete: true, card: null }), 'ACTIVE');
});
test('missing server billing cannot be bypassed by client flags', () => {
  const store = makeStore({ billing: null });
  assert.throws(() => activate(store, { request: request({ paymentStepComplete: true, billingVerified: true }) }), code('BILLING_REQUIRED'));
  assert.equal(store.snapshot().outbox.length, 0);
  assert.equal(store.snapshot().campaigns[0].status, 'DRAFT');
});
test('an approved credit account is eligible without requiring a credit card', () => {
  assert.equal(activate(makeStore({ billing: { kind: 'APPROVED_CREDIT', status: 'VERIFIED' } })).status, 'PENDING_DELIVERY');
});
test('unverified card fails', () => assert.throws(() => activate(makeStore({ billing: { kind: 'CARD', status: 'PENDING' } })), code('BILLING_REQUIRED')));
test('unknown billing scheme fails closed', () => assert.throws(() => activate(makeStore({ billing: { kind: 'CLIENT_FLAG', status: 'VERIFIED' } })), code('BILLING_REQUIRED')));
test('another actor cannot activate an account campaign', () => assert.throws(() => activate(makeStore(), { actor: 'bob' }), code('FORBIDDEN')));
test('a campaign cannot be activated through another account', () => assert.throws(() => activate(makeStore(), { campaignId: 'campaign-b' }), code('FORBIDDEN')));
test('unknown account fails without disclosing campaign data', () => assert.throws(() => activate(makeStore(), { accountId: 'missing' }), code('FORBIDDEN')));
test('inactive account fails', () => {
  const store = makeStore(); store.updateAccount('account-a', { status: 'SUSPENDED' });
  assert.throws(() => activate(store), code('FORBIDDEN'));
});
test('forged client account identity is ignored', () => {
  assert.equal(activate(makeStore(), { request: request({ actor: 'bob', accountId: 'account-b' }) }).campaignId, 'campaign-a');
});
for (const budgetCents of [0, -1, 1.5, NaN, Infinity, Number.MAX_SAFE_INTEGER + 1, 50001, '12000', null]) {
  test(`invalid integer-cent budget ${String(budgetCents)} fails`, () => assert.throws(() => activate(makeStore(), { request: request({ budgetCents }) }), code('INVALID_BUDGET')));
}
test('allowed budget boundaries pass', () => {
  for (const budgetCents of [1, 50000]) assert.equal(activate(makeStore(), { request: request({ budgetCents }) }).status, 'PENDING_DELIVERY');
});
test('currency must match trusted account currency', () => assert.throws(() => activate(makeStore(), { request: request({ currency: 'USD' }) }), code('INVALID_CURRENCY')));
test('invalid idempotency key fails', () => assert.throws(() => activate(makeStore(), { request: request({ idempotencyKey: 'short' }) }), code('INVALID_KEY')));
test('non-draft lifecycle cannot activate', () => assert.throws(() => activate(makeStore({ status: 'CANCELLED' })), code('INVALID_TRANSITION')));
test('duplicate concurrent-looking callers produce one receipt and one outbox event', async () => {
  const store = makeStore();
  const responses = await Promise.all(Array.from({ length: 25 }, () => Promise.resolve().then(() => activate(store))));
  assert.ok(responses.every(result => JSON.stringify(result) === JSON.stringify(responses[0])));
  assert.equal(store.snapshot().receipts.length, 1); assert.equal(store.snapshot().outbox.length, 1);
});
test('same key with changed budget is a conflict', () => {
  const store = makeStore(); activate(store);
  assert.throws(() => activate(store, { request: request({ budgetCents: 13000 }) }), code('IDEMPOTENCY_CONFLICT'));
});
test('same actor and account key cannot activate another campaign', () => {
  const store = new CampaignStore({ accounts: [{ id: 'account-a', status: 'ACTIVE', operators: ['alice'], currency: 'AUD', maxCampaignCents: 50000, billing: { kind: 'CARD', status: 'VERIFIED' } }], campaigns: [{ id: 'campaign-a', accountId: 'account-a', status: 'DRAFT' }, { id: 'campaign-c', accountId: 'account-a', status: 'DRAFT' }] });
  activate(store); assert.throws(() => activate(store, { campaignId: 'campaign-c' }), code('IDEMPOTENCY_CONFLICT'));
});
test('receipt replay still checks the current actor membership', () => {
  const store = makeStore(); activate(store); store.updateAccount('account-a', { operators: [] });
  assert.throws(() => activate(store), code('FORBIDDEN'));
});
test('returned copies cannot modify stored receipts', () => {
  const store = makeStore(); const first = activate(store); first.status = 'FORGED';
  assert.equal(activate(store).status, 'PENDING_DELIVERY');
});
test('dispatch makes the fictional campaign active and deduplicates repeated jobs', () => {
  const store = makeStore(); const result = activate(store);
  assert.deepEqual(store.deliver(result.eventId), store.deliver(result.eventId));
  assert.equal(store.snapshot().campaigns[0].status, 'ACTIVE');
});
test('billing revocation after activation prevents later delivery', () => {
  const store = makeStore(); const result = activate(store); store.updateAccount('account-a', { billing: null });
  assert.throws(() => store.deliver(result.eventId), code('BILLING_REQUIRED'));
  assert.equal(store.snapshot().campaigns[0].status, 'PENDING_DELIVERY');
  assert.equal(store.snapshot().outbox[0].status, 'PENDING');
});
test('membership revocation after activation prevents later delivery', () => {
  const store = makeStore(); const result = activate(store); store.updateAccount('account-a', { operators: [] });
  assert.throws(() => store.deliver(result.eventId), code('FORBIDDEN'));
});
test('changed spending policy is revalidated before delivery', () => {
  const store = makeStore(); const result = activate(store); store.updateAccount('account-a', { maxCampaignCents: 1000 });
  assert.throws(() => store.deliver(result.eventId), code('INVALID_INTENT'));
});
test('XSS-looking content is assigned only to a text sink', () => {
  const element = { textContent: '', set innerHTML(_) { throw new Error('HTML sink used'); } };
  const harmlessMarker = '<img src=x onerror="this.dataset.demo=\'marker\'">';
  renderLabel(element, harmlessMarker); assert.equal(element.textContent, harmlessMarker);
});
test('CSRF check accepts the configured origin and session-bound token', () => {
  assert.doesNotThrow(() => requireCsrf({ origin: 'https://example.invalid', expectedOrigin: 'https://example.invalid', token, sessionToken: token }));
});
test('CSRF check rejects a cross-origin request even with correct token', () => {
  assert.throws(() => requireCsrf({ origin: 'https://other.invalid', expectedOrigin: 'https://example.invalid', token, sessionToken: token }), code('CSRF_ORIGIN'));
});
test('CSRF check rejects a missing origin', () => assert.throws(() => requireCsrf({ expectedOrigin: 'https://example.invalid', token, sessionToken: token }), code('CSRF_ORIGIN')));
for (const supplied of [undefined, '', 'short', 'x'.repeat(token.length), 'x'.repeat(257)]) {
  test(`CSRF check rejects missing or incorrect token ${String(supplied).slice(0,12)}`, () => assert.throws(() => requireCsrf({ origin: 'https://example.invalid', expectedOrigin: 'https://example.invalid', token: supplied, sessionToken: token }), code('CSRF_TOKEN')));
}
