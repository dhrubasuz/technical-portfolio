# Security policy

Maintainer and author: Dhruba Poudel

Trust Boundary Lab is an original, local-only educational model. The deliberately flawed client-completion decision is included to explain a trust-boundary error. It is not an exposed service or a production payment implementation.

## Intended scope

Run the supplied code locally using its fictional accounts, tokens and campaigns. It makes no network calls and has no configurable live target. The project does not authorize testing Facebook, Meta, a payment provider or any other third-party service. This repository is not a reconstruction of Facebook source code or proof of a historical vulnerability's mechanism or severity.

The corrected examples are bounded models rather than a complete security framework. Production requirements and unimplemented boundaries are documented in the README. The intentionally insecure decision is not a newly discovered vulnerability in this repository.

## Reporting a concern

For a non-sensitive correctness or documentation problem, open a GitHub issue with a minimal reproduction using only the fictional fixtures. Do not include credentials, payment information, customer records, private reports or live-target exploit instructions.

For a sensitive concern, use GitHub's private vulnerability reporting feature if it is available on this repository. Do not disclose sensitive data in a public issue. No bug-bounty payment, response deadline or production support commitment is offered by this project.
