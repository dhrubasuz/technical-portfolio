// Author: Dhruba Poudel. Fictional local-only demonstration.
import { CampaignStore, vulnerableDecision } from './campaign-security.mjs';

const seed = billing => ({
  accounts: [{ id: 'demo-account', status: 'ACTIVE', operators: ['researcher'],
    currency: 'AUD', maxCampaignCents: 50000, billing }],
  campaigns: [{ id: 'demo-campaign', accountId: 'demo-account', status: 'DRAFT' }],
});
const command = {
  actor: 'researcher', accountId: 'demo-account', campaignId: 'demo-campaign',
  request: { budgetCents: 12000, currency: 'AUD', idempotencyKey: 'demo_intent_0001',
    paymentStepComplete: true, billingVerified: true },
};

console.log('Fictional local teaching model. No Facebook or payment service is contacted.');
console.log('Flawed UI-completion decision:', vulnerableDecision(command.request));
const withoutBilling = new CampaignStore(seed(null));
try { withoutBilling.activate(command); }
catch (error) { console.log('Server decision with no trusted billing:', error.code); }

const withApprovedCredit = new CampaignStore(seed({ kind: 'APPROVED_CREDIT', status: 'VERIFIED' }));
const receipt = withApprovedCredit.activate(command);
console.log('Server decision with approved account credit:', receipt.status);
console.log('Repeated command returns same event:', withApprovedCredit.activate(command).eventId === receipt.eventId);
console.log('Revalidated simulated dispatch:', withApprovedCredit.deliver(receipt.eventId).status);
console.log('Final fictional campaign state:', withApprovedCredit.snapshot().campaigns[0].status);
